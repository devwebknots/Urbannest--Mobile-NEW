/**
 * Neyora Maintenance SDK
 * Lets a host app show Neyora's screens natively inside its own navigation.
 *
 * Usage in a host app (already inside its NavigationContainer):
 *   import { NeyoraModule } from '@neyora/maintenance-sdk';
 *   <Stack.Screen name="Neyora" component={NeyoraModule} />
 */

import React, { ReactNode } from 'react';
import { Provider } from 'react-redux';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { store } from './src/store';
import { HomeScreen } from './src/features/home';
import { CalendarScreen } from './src/features/calendar';

export interface NeyoraProviderProps {
  /** Licence key for the host app (demo: accepted, not checked yet) */
  readonly apiKey?: string;
  readonly children: ReactNode;
}

/** Neyora's own store, kept separate from the host app's store */
export const NeyoraProvider: React.FC<NeyoraProviderProps> = ({ children }) => (
  <Provider store={store}>{children}</Provider>
);

const Stack = createNativeStackNavigator();

export interface NeyoraModuleProps {
  readonly apiKey?: string;
}

/** The full Neyora module: Home first, then Calendar */
export const NeyoraModule: React.FC<NeyoraModuleProps> = ({ apiKey }) => (
  <NeyoraProvider apiKey={apiKey}>
    <Stack.Navigator
      initialRouteName="Home"
      screenOptions={{ headerShown: false, animation: 'fade' }}
    >
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen
        name="Calendar"
        component={CalendarScreen}
        options={{ animation: 'slide_from_right' }}
      />
    </Stack.Navigator>
  </NeyoraProvider>
);

export default NeyoraModule;
