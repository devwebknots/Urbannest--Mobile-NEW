/**
 * Public types for host apps, so they don't type-check Neyora's source.
 */

import type React from 'react';
import type { ReactNode } from 'react';

export interface NeyoraProviderProps {
  /** Licence key for the host app (demo: accepted, not checked yet) */
  readonly apiKey?: string;
  readonly children: ReactNode;
}

export interface NeyoraModuleProps {
  readonly apiKey?: string;
}

export declare const NeyoraProvider: React.FC<NeyoraProviderProps>;
export declare const NeyoraModule: React.FC<NeyoraModuleProps>;
export default NeyoraModule;
